<?php

return [
    'views' => [
        'index',
        'add',
        'edit',
        'json',
        'remove'
    ]
];