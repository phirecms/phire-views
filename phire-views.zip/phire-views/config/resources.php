<?php

return [
    'views' => [
        'index',
        'add',
        'edit',
        'remove'
    ]
];