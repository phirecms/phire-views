<?php

namespace Phire\Views\Event;

use Phire\Views\Table;
use Pop\Application;

class View
{

    /**
     * Bootstrap the module
     *
     * @param  Application $application
     * @return void
     */
    public static function bootstrap(Application $application)
    {

    }

}